function setup() {
  createCanvas(600,600);
}

function draw() {
  background(220);
  strokeWeight(7);
  line(200,50,200,550);
  line(400,50,400,550);
  line(50,200,550,200);
  line(50,400,550,400);
}